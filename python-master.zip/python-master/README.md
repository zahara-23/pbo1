# python
Belajar dasar-dasar python yang dimulai dari pengenalan sintaks print
